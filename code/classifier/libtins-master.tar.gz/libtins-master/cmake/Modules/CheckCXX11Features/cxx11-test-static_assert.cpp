int main(void)
{
	static_assert(0 < 1, "your ordering of integers is screwed");
	return 0;
}
